# Generated automatically -- do not modify!    -*- buffer-read-only: t -*-
VERSION = "1.7.90"
